<?php

namespace AutomateWoo;

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * @class Action_Send_SMS_Twilio
 */
class Action_Send_SMS_Twilio extends Action {


	function load_admin_details() {
		$this->title = __( 'Send SMS (Twilio)', 'automatewoo' );
		$this->group = __( 'SMS', 'automatewoo' );
		$this->description = __( "It is recommended to include an unsubscribe link by using the variable {{ customer.unsubscribe_url }} in the SMS body.", 'automatewoo' );
	}


	function load_fields() {
		$sms_recipient = ( new Fields\Text() )
			->set_name( 'sms_recipient' )
			->set_title( __( 'SMS recipients', 'automatewoo' ) )
			->set_description( __( 'Multiple recipient numbers must be separated by commas. When using the {{ customer.phone }} variable the country code will be added automatically, if not already entered by the customer, by referencing the billing country.', 'automatewoo' ) )
			->set_variable_validation()
			->set_required();

		$sms_body = ( new Fields\Text_Area() )
			->set_name( 'sms_body' )
			->set_title( __( 'SMS body', 'automatewoo' ) )
			->set_rows(4)
			->set_variable_validation()
			->set_required();

		$this->add_field( $sms_recipient );
		$this->add_field( $sms_body );
	}


	function run() {
		$recipients = Clean::comma_delimited_string( $this->get_option( 'sms_recipient', true ) );
		$sms_body = Clean::textarea( $this->get_option( 'sms_body', true ) );

		$customer = $this->workflow->data_layer()->get_customer();

		if ( empty( $recipients ) ) {
			$this->workflow->log_action_error( $this, __( 'No valid recipients', 'automatewoo') );
			return;
		}

		if ( empty( $sms_body ) ) {
			$this->workflow->log_action_error( $this, __( 'Empty message body', 'automatewoo') );
			return;
		}

		// process URLs in sms body
		$replacer = new Replace_Helper( $sms_body, [ $this, 'callback_process_url' ], 'text_urls' );
		$sms_body = $replacer->process();

		if ( ! $twilio = Integrations::get_twilio() ) {
			return;
		}

		foreach ( $recipients as $recipient ) {

			// check if SMS is sending to the customer, not the admin for example
			if ( $this->is_sms_to_customer( $customer, $recipient ) ) {

				// check if the customer is unsubscribed
				if ( $this->workflow->is_customer_unsubscribed( $customer ) ) {
					$error = new \WP_Error( 'unsubscribed', sprintf( __( "The recipient is unsubscribed.", 'automatewoo' ), $customer->get_id() ) );
					$this->workflow->log_action_email_error( $error, $this );
					continue; // skip this recipient
				}

				$recipient = Phone_Numbers::parse( $recipient, $customer->get_billing_country() );
			}
			else {
				$recipient = Phone_Numbers::parse( $recipient );
			}

			$request = $twilio->send_sms( $recipient, $sms_body );

			if ( $request->is_successful() ) {
				$this->workflow->log_action_note( $this, sprintf( __( 'SMS successfully sent.', 'automatewoo' ), $recipient ) );
			}
			else {
				$this->workflow->log_action_error( $this, $twilio->get_request_error_message( $request ) );
			}

		}
	}


	/**
	 * @param Customer $customer
	 * @param string $recipient_phone
	 * @return bool
	 */
	public function is_sms_to_customer( $customer, $recipient_phone ) {
		if ( ! $customer || ! $recipient_phone ) {
			return false;
		}

		if ( $recipient_phone == $customer->get_billing_phone() ) {
			return true;
		}

		// attempt matching again by parsing the stored customer billing phone
		if ( $recipient_phone == Phone_Numbers::parse( $customer->get_billing_phone(), $customer->get_billing_country() ) ) {
			return true;
		}

		return false;
	}


	/**
	 * @param string $url
	 * @return string
	 */
	public function callback_process_url( $url ) {
		$url = html_entity_decode( $url );

		if ( $this->workflow->is_tracking_enabled() ) {
			// don't track unsubscribe clicks
			if ( ! strstr( $url, 'aw-action=unsubscribe' ) ) {
				$url = $this->workflow->append_ga_tracking_to_url( $url );
				$url = Tracking::get_click_tracking_url( $this->workflow, $url );
			}
		}

		// shorten links
		if ( AW()->options()->bitly_shorten_sms_links && $bitly = Integrations::get_bitly() ) {
			$url = $bitly->shorten_url( $url );
		}

		return $url;
	}


}
