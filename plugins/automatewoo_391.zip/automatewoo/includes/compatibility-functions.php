<?php
/**
 * Add compatible functions for older versions of WC or WP
 */
