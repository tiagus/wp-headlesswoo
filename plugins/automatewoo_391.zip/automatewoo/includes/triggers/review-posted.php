<?php

namespace AutomateWoo;

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * @class Trigger_Review_Posted
 */
class Trigger_Review_Posted extends Trigger {

	public $supplied_data_items = [ 'review', 'customer', 'product' ];


	function load_admin_details() {
		$this->title = __( 'New Review Posted', 'automatewoo' );
		$this->group = __( 'Reviews', 'automatewoo' );
		$this->description = __( 'This trigger does not fire until the review has been approved.', 'automatewoo' );
	}


	function register_hooks() {
		add_action( 'automatewoo/review/posted', [ $this, 'catch_hooks' ] );
	}


	/**
	 * @param Review $review
	 */
	function catch_hooks( $review ) {
		$this->maybe_run([
			'customer' => Customer_Factory::get_by_review( $review ),
			'product' => wc_get_product( $review->get_product_id() ),
			'review' => $review
		]);
	}


	/**
	 * @param $workflow Workflow
	 * @return bool
	 */
	function validate_workflow( $workflow ) {
		// only run once for each comment and workflow
		// the comment could be approved more than once
		if ( $workflow->has_run_for_data_item( 'review' ) ) {
			return false;
		}

		return true;
	}

}
