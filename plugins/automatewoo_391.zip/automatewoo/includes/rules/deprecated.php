<?php

/** @deprecated */
abstract class AW_Rule_Abstract extends AutomateWoo\Rules\Rule {}

/** @deprecated  */
abstract class AW_Rule_Abstract_Bool extends AutomateWoo\Rules\Abstract_Bool {}

/** @deprecated dependency in RAF removed in v1.9  */
abstract class AW_Rule_Abstract_Number extends AutomateWoo\Rules\Abstract_Number {}

/** @deprecated  */
abstract class AW_Rule_Abstract_Object extends AutomateWoo\Rules\Abstract_Object {}

/** @deprecated  */
abstract class AW_Rule_Abstract_Select extends AutomateWoo\Rules\Abstract_Select {}

/** @deprecated  */
abstract class AW_Rule_Abstract_String extends AutomateWoo\Rules\Abstract_String {}
