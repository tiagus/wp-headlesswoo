<?php

namespace AutomateWoo;

/**
 * @class Query_Custom_Table
 * @since 2.0
 * @deprecated
 */
abstract class Query_Custom_Table extends Query_Abstract {}
