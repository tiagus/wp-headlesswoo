<?php

namespace AutomateWoo;

/**
 * @class Events
 * @since 3.4.0
 */
class Events {

	/** @var Events_Runner_Async_Request  */
	private static $events_runner_async_request;

	/** @var array of event IDs */
	static $events_runner_async_request_data = [];


	/**
	 * @return Events_Runner_Async_Request
	 */
	static function get_event_runner_async_request() {
		if ( ! isset( self::$events_runner_async_request ) ) {
			self::$events_runner_async_request = new Events_Runner_Async_Request();
		}
		return self::$events_runner_async_request;
	}


	/**
	 * @return int
	 */
	static function get_batch_size() {
		return (int) apply_filters( 'automatewoo/events/batch_size', 50 );
	}


	/**
	 * Check for events due to be run
	 */
	static function run_due_events() {

		/** @var Background_Processes\Event_Runner $process */
		$process = Background_Processes::get('events');

		// don't start a new process until the previous is finished
		if ( $process->has_queued_items() ) {
			$process->maybe_schedule_health_check();
			return;
		}

		$query = ( new Event_Query() )
			->set_limit( self::get_batch_size() )
			->set_ordering( 'date_scheduled', 'ASC' )
			->where( 'date_scheduled', new \DateTime(), '<' )
			->where( 'status', 'pending' )
			->set_return( 'ids' );

		if ( ! $events = $query->get_results() ) {
			return;
		}

		$process->data( $events )->start();
	}


	/**
	 * Schedule async event.
	 *
	 * If AUTOMATEWOO_ENABLE_INSTANT_EVENT_DISPATCHING is true a HTTP request will be dispatched
	 * at shutdown that will instantly run the event.
	 *
	 * @param string $hook
	 * @param array $args
	 * @return Event
	 */
	static function schedule_async_event( $hook, $args = [] ) {
		if ( AUTOMATEWOO_ENABLE_INSTANT_EVENT_DISPATCHING ) {
			// when using instant event dispatching increase the delay to avoid event
			// duplication since the delay is used by the cron based event runner
			// this acts as a fallback if the http request failed.
			// Note that if the background processor doesn't start because it's already running
			// we automatically reduce this delay
			$delay = 180;
		}
		else {
			$delay = 5;
		}

		$date = new \DateTime();
		$date->setTimestamp( time() + $delay );

		$event = Events::schedule_event( $date, $hook, $args );

		if ( AUTOMATEWOO_ENABLE_INSTANT_EVENT_DISPATCHING ) {
			Events::dispatch_events_starter_request_at_shutdown( $event->get_id() );
		}

		if ( AUTOMATEWOO_LOG_ASYNC_EVENTS ) {
			$logger = new \WC_Logger();
			$logger->add( 'automatewoo-async-event', $hook. ': ' . print_r( $args, true ) );
		}

		return $event;
	}


	/**
	 * @param \DateTime|string|int $date accepts timestamp
	 * @param string $hook
	 * @param array $args
	 * @return Event
	 */
	static function schedule_event( $date, $hook, $args = [] ) {
		if ( is_numeric( $date ) ) {
			$timestamp = $date;
			$date = new \DateTime();
			$date->setTimestamp( $timestamp );
		}

		$event = new Event();
		$event->set_status( 'pending' );
		$event->set_hook( $hook );
		$event->set_args( $args );
		$event->set_date_scheduled( $date );
		$event->save();
		return $event;
	}


	/**
	 * Unschedules all events attached to the hook with the specified arguments.
	 *
	 * @param string $hook
	 * @param array $args optional
	 */
	static function clear_scheduled_hook( $hook, $args = [] ) {

		$query = new Event_Query();
		$query->where('hook', $hook );

		if ( $args ) {
			$query->where('args_hash', md5(serialize(Clean::recursive($args))) );
		}

		$events = $query->get_results();

		foreach( $events as $event ) {
			$event->delete();
		}
	}


	/**
	 * Experimental method to run the events background processor at the shut down event.
	 * To reduce the delay involved in async events.
	 *
	 * @param int|bool $event_id
	 * @since 3.7
	 */
	static function dispatch_events_starter_request_at_shutdown( $event_id ) {
		self::$events_runner_async_request_data[] = $event_id;
		add_action( 'shutdown', [ 'AutomateWoo\Events', 'dispatch_events_starter_request' ] );
	}


	static function dispatch_events_starter_request() {
		self::get_event_runner_async_request()->data( self::$events_runner_async_request_data )->dispatch();
	}


}
