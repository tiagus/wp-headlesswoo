<?php

/** @deprecated */
abstract class AW_Variable extends AutomateWoo\Variable {}

/** @deprecated */
abstract class AW_Variable_Abstract_Generate_Coupon extends AutomateWoo\Variable_Abstract_Generate_Coupon {}

/** @deprecated */
abstract class AW_Variable_Abstract_Datetime extends AutomateWoo\Variable_Abstract_Datetime {}

/** @deprecated */
abstract class AW_Variable_Abstract_Meta extends AutomateWoo\Variable_Abstract_Meta {}

/** @deprecated */
abstract class AW_Variable_Abstract_Product_Display extends AutomateWoo\Variable_Abstract_Product_Display {}
