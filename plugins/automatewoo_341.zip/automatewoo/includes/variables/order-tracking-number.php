<?php

namespace AutomateWoo;

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * @class Variable_Order_Tracking_Number
 */
class Variable_Order_Tracking_Number extends Variable_Abstract_Shipment_Tracking {


	function load_admin_details() {
		$this->description = sprintf(
			__( "Displays the tracking number as set with the <a href='%s' target='_blank'>WooThemes Shipment Tracking</a> plugin.", 'automatewoo'),
			'https://www.woothemes.com/products/shipment-tracking/'
		);
	}


	/**
	 * @param $order \WC_Order
	 * @param $parameters array
	 * @return string
	 */
	function get_value( $order, $parameters ) {
		return $this->display_order_wc_shipment_tracking( $order_id, '_tracking_number' );
	}
}

return new Variable_Order_Tracking_Number();
