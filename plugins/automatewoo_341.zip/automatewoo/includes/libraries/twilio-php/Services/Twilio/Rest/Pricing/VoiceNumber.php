<?php

class Services_Twilio_Rest_Pricing_VoiceNumber
    extends Services_Twilio_PricingInstanceResource {
}